A Memento preserves the public catalogue facts, editorial summaries and provenance known at capture time. It does not copy complete source articles or prove their contents independently. Original pages and external photographs retain their rights. Raw research caches, accounts, private collections and moderation queues are excluded.

Verify each capsule by removing snapshot_sha256, encoding canonical UTF-8 JSON with sorted keys and compact separators, and comparing SHA-256. Source hashes have their own explicit scope.

Local licensed media is included only when the bundle manifest says so. External references remain links. No complete source articles or private raw HTML caches are included.
